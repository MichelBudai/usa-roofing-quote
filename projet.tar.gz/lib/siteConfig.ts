/** Canonical base URL for the site. Used for metadataBase, sitemap, robots, canonicals. */
export const SITE_BASE_URL =
  process.env.NEXT_PUBLIC_SITE_URL || "https://usa-plumber-quote.com";

/** Site-wide phone and call CTA. Use for all "call" links and buttons. */
export const PHONE_TEL = "tel:+15551234567";
export const PHONE_DISPLAY = "(555) 123-4567";
export const CTA_CALL_LABEL = `Call Now - ${PHONE_DISPLAY}`;
