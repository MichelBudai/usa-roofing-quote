/**
 * Client-safe constants (no Node/fs). Use this from "use client" components.
 */

export const SERVICE_SLUGS = [
  "plumbing-quote",
  "repiping-quote",
  "water-heater-replacement-quote",
  "sewer-line-replacement-quote",
  "drain-line-replacement-quote",
  "emergency-plumbing-quote",
] as const;

export type ServiceSlug = (typeof SERVICE_SLUGS)[number];

export const SERVICE_LABELS: Record<ServiceSlug, string> = {
  "plumbing-quote": "Plumbing Quote",
  "repiping-quote": "Repiping Quote",
  "water-heater-replacement-quote": "Water Heater Replacement Quote",
  "sewer-line-replacement-quote": "Sewer Line Replacement Quote",
  "drain-line-replacement-quote": "Drain Line Replacement Quote",
  "emergency-plumbing-quote": "Emergency Plumbing Quote",
};
